const router= require('express').Router()
const cbanner=require('../controllers/bannercontroller')
const Baner= require('../models/banner')
const Query= require('../models/query')
const Testi= require('../models/testi')
const multer=require('multer')
const Services= require('../models/services')
const Reg= require('../models/reg')
const bcrypt= require('bcrypt')
let sess= null;


function handleroles(req,res,next){
    if(sess.role=='pvt'){
        next()
    }else{
        res.send('you don t have rights to see the page')
    }
}




function handlelogin(req,res,next){
    if(req.session.isAuth){
        next()
    }else{
        res.redirect('/login')
    }
}
let storage= multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,'./public/upload')
    },
    filename:function(req,file,cb){
        cb(null, Date.now()+file.originalname)
    }
})


let upload= multer({
    storage:storage,
    limits:{fileSize:1024*1024*4}
})



router.get('/',handlelogin,async(req,res)=>{
    const bannerRecord= await Baner.findOne()
    const testirecords= await Testi.find({status:'publish'})
    const serviceREcord= await Services.find({status:'publish'})
    //console.log(sess.username)
    //console.log(bannerRecord)
    res.render('index.ejs',{bannerRecord,testirecords,serviceREcord,loginuser:sess.username})
})


router.get('/banner',cbanner.bannershow)

router.post('/queryrecord',(req,res)=>{
    let postedDate= new Date()
    const{email,query,}= req.body
    const queryrecord= new Query ({email:email,query:query,status:'unread',postedDate:postedDate})
    queryrecord.save()
    res.redirect('/')

})


router.get('/testi',handleroles,(req,res)=>{
    if(sess!==null){
    res.render('testi.ejs',{loginuser:sess.username})
    }else{
        res.render('testi.ejs',{loginuser:'hello'})
    }
})



router.post('/testirecords',upload.single('img'), async(req,res)=>{
    //console.log(req.file)
    const{quote,cname}= req.body
    const testirecord= new Testi({quote:quote,cname:cname,status:'unpublish',userImage:req.file.filename, postedDate:new Date()})
    await testirecord.save()
    //console.log(testirecord)
})



router.get('/service/:id',async (req,res)=>{
    const serviceRecord= await Services.findById(req.params.id)
    res.render('service.ejs',{serviceRecord})

})



router.get('/reg',(req,res)=>{
    if(sess!==null){
        res.render('reg.ejs',{loginuser:sess.username})
    }else{
        res.render('reg.ejs',{loginuser:'hello'})
    }
    res.render('reg.ejs')
})



router.post('/regrecord',async(req,res)=>{
    const{username,password}= req.body
    const convertedPassword=await bcrypt.hash(password,10)
    const regRecord= new Reg({username:username,password:convertedPassword,status:'suspended',role:'public',firstName:'',lastName:'',email:'',img:''})
    await regRecord.save()
    res.redirect('/login')
    //console.log(regRecord)
})



router.get('/login',(req,res)=>{
    if(sess!==null){
    res.render('login.ejs',{message:'',loginuser:sess.username})
    }else{
        res.render('login.ejs',{message:'',loginuser:'hello'})
    }
})


router.post('/loginrecord',async(req,res)=>{
    const {user,pass}=req.body
    const regrecord= await Reg.findOne({username:user})
    //console.log(regrecord)
    if(regrecord!==null){
        const comparepass= await bcrypt.compare(pass,regrecord.password)
        if(comparepass){
            if(regrecord.status=='active'){
            req.session.isAuth=true
            sess=req.session
            sess.username=user
            sess.role=regrecord.role
        res.redirect('/')
       }else{
        if(sess!==null){
            res.render('login.ejs',{message:'Your account is Suspended',loginuser:sess.username})
            }else{
                res.render('login.ejs',{message:'Your account is Suspended',loginuser:'hello'})
            }
       }
    }else{
        if(sess!==null){
            res.render('login.ejs',{message:'Wrong credentails',loginuser:sess.username})
            }else{
                res.render('login.ejs',{message:'Wrong credentails',loginuser:'hello'})
            }
    }
    }else{
        if(sess!==null){
            res.render('login.ejs',{message:'Wrong credentails',loginuser:sess.username})
            }else{
                res.render('login.ejs',{message:'Wrong credentails',loginuser:'hello'})
            }
    }
    
})


router.get('/logout',(req,res)=>{
    req.session.destroy()
    sess=null
    res.redirect('/login')

})


router.get('/profile',handlelogin,async(req,res)=>{
    if(sess!==null){
         const profileRecord= await Reg.findOne({username:sess.username})
         //console.log(profileRecord)
        res.render('profile.ejs',{message:'',profileRecord,loginuser:sess.username})
    }else{
        res.render('profile.ejs',{message:'',loginuser:'hello'})
    }
    
})


router.post('/profileupdate/:id',upload.single('img'),async(req,res)=>{
    const id= req.params.id
    const{fname,lname,email}=req.body
    if(req.file){
        const imgName= req.file.filename
        await Reg.findByIdAndUpdate(id,{firstName:fname,LastName:lname,email:email,img:imgName})
    }else{
        const imgName='4.png'
        await Reg.findByIdAndUpdate(id,{firstName:fname,LastName:lname,email:email,img:imgName})
    }
    
    if(sess!==null){
        const profileRecord= await Reg.findOne({username:sess.username})
        //console.log(profileRecord)
       res.render('profile.ejs',{message:'Profile has been Updated',profileRecord,loginuser:sess.username})
   }else{
       res.render('profile.ejs',{message:'Profile has been Updated',loginuser:'hello'})
   }
})












module.exports= router;