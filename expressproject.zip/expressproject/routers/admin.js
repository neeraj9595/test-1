const router= require('express').Router()
const cbanner=require('../controllers/bannercontroller')
const cservices= require('../controllers/servicescontroller')
const creg=require('../controllers/regcontroller')
const cparking=require('../controllers/parkingcontroller')
const ctesti=require('../controllers/testicontroller')
const cquery=require('../controllers/querycontroller')
const Admin= require('../models/adminlogin')
const Banner= require('../models/banner')
const Query= require('../models/query')
const nodemailer= require('nodemailer')
const Testi= require('../models/testi')
const multer=require('multer')
const Services= require('../models/services')
const Service= require('../models/services')
const Reg= require('../models/reg')
const Parking= require('../models/parking')
const testi = require('../models/testi')

const storage= multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,'./public/upload')
    },
    filename:function(req,file,cb){
        cb(null, Date.now()+file.originalname)
    }
})


const upload= multer({
    storage:storage,
    limits:{fieldSize:1024*1024*4}
})

function handlelogin(req,res,next){
    if(req.session.isAuth){
        next()
    }else{
        res.redirect('/admin/')
    }
}


router.get('/',(req,res)=>{
    res.render('admin/adminlogin.ejs',{message:''})
})




router.post('/loginrecord',async(req,res)=>{
    const{username,password}= req.body
    const d= await Admin.findOne({username:username})
    if(d!==null){
        if(d.password==password){
            req.session.isAuth=true
            res.redirect('/admin/dasboard')
        }else{
            res.render('admin/adminlogin.ejs',{message:'wrong credentails'})
        }
        
    }else(
        res.render('admin/adminlogin.ejs',{message:'wrong credentails'})
    )
})


router.get('/dasboard',handlelogin,(req,res)=>{
    res.render('admin/dasboard.ejs')
})


router.get('/logout',(req,res)=>{
    req.session.destroy()
    res.redirect('/admin/')
})


router.get('/banner',cbanner.bannershowadmin)

router.get('/bannerupdate/:abc',cbanner.bannerupdateformadmin)


router.post('/bannerrecord/:xyz',upload.single('img'),cbanner.bannerupdateadmin)



router.get('/query',cquery.querycontrolleradmin)

router.get('/queryupdate/:abc',cquery.queryupdatecontrolleradmin)


router.get('/email/:xyz',(req,res)=>{
    const id= req.params.xyz
    res.render('admin/email.ejs',{id})
})


router.post('/emailrecord/:abc',async (req,res)=>{
    const id= req.params.abc
    const useremail= await Query.findById(req.params.abc)
    const{emailto,emailsubject,body}= req.body
    let testAccount = await nodemailer.createTestAccount();

  // create reusable transporter object using the default SMTP transport
  let transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 587,
    secure: false, // true for 465, false for other ports
    auth: {
      user: 'nitin07.ny@gmail.com', // generated ethereal user
      pass: 'prkrbltdgpkgrilf', // generated ethereal password
    },
  });

  let info = await transporter.sendMail({
    from: 'nitin07.ny@gmil.com', // sender address
    to:useremail.email , // list of receivers
    subject:emailsubject, // Subject line
    text: body, // plain text body
    //html: "<b>Hello world?</b>", // html body
    attachments:[{
        path:'public/media/3.png'
    }]
  });

  await Query.findByIdAndUpdate(id,{status:'read'})
  res.redirect('/admin/query')
})


router.get('/testi',ctesti.testicontrolleradmin)


router.get('/testiupdate/:xyz',ctesti.testiupdatecontrolleradmin)


router.get('/querydelete/:xyz',cquery.querydeletecontrolleradmin)

router.get('/testidelete/:abc',ctesti.testideletecontrolleradmin)

router.get('/services',cservices.servicesshowadmin)

router.get('/serviceadd',cservices.servicesaddformadmin)


router.post('/servicerecords',upload.single('simage'),cservices.servicesinsertadmin)


router.get('/serviceupdate/:id',cservices.servicesupdateadmin)

router.get('/servicedelete/:id',cservices.servicesdeleteadmin)

router.get('/emailtest',async (req,res)=>{
    })


router.get('/user',creg.usercontrolleradmin)

router.get('/userupdate/:abc',creg.userupdatecontrolleradmin)


router.get('/userroleupdate/:abc',creg.userrolecontrolleradmin)


router.get('/userdelete/:abc',creg.userdeletecontrolleradmin)


router.get('/parking',cparking.parkingcontrolleradmin)

router.get('/parkingadd',cparking.parkingaddcontrolleradmin)


router.post('/parkingrecords',cparking.parkinginsertcontrolleradmin)


router.get('/parkingout/:id',cparking.parkingoutcontrolleradmin)

router.get('/parkingupdate/:id',cparking.parkingupdatecontrolleradmin)


router.get('/parkingprint/:id',cparking.parkingprintcontrolleradmin)





//----------------------test url--------------------//

router.get('/test',(req,res)=>{
    res.send('testing')
    const x= new Banner({title:'banner title',desc:'banner desc',longdesc:'long desc banner'})
    x.save()
})












module.exports= router;