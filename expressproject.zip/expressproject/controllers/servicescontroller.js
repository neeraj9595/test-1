const Services= require('../models/services')






exports.servicesshowadmin=async (req,res)=>{
    const serviceREcord= await Services.find()
    res.render('admin/services.ejs',{serviceREcord})
}

exports.servicesaddformadmin=(req,res)=>{
    res.render('admin/serviceform.ejs')
}

exports.servicesinsertadmin=async (req,res)=>{
    const imageName= req.file.filename
    const{sname,desc,ld}=req.body
    const serviceREcord= new Services({img:imageName,serviceName:sname,serviceDesc:desc,serviceLongDesc:ld,status:'unpublish'})
    await serviceREcord.save()
    //console.log(serviceREcord)
    res.redirect('/admin/services')
}

exports.servicesupdateadmin=async (req,res)=>{
    const id= req.params.id
    const serviceRecord=await Services.findById(id)
    let newStatus=null;
    if(serviceRecord.status=='unpublish'){
        newStatus='publish'
    }else{
        newStatus='unpublish'
    }
    await Services.findByIdAndUpdate(id,{status:newStatus})
    res.redirect('/admin/services')
}

exports.servicesdeleteadmin=async(req,res)=>{
    const id=req.params.id
    await Services.findByIdAndDelete(id)
    res.redirect('/admin/services')
}