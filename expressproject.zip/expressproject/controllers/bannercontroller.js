const Baner= require('../models/banner')


let sess=null;




exports.bannershow=async (req,res)=>{
    const bannerRecord= await Baner.findOne()
    if(sess!==null){
    //console.log(bannerRecord.title)
   res.render('banner.ejs',{bannerRecord,loginuser:sess.username})
}else{
    res.render('banner.ejs',{bannerRecord,loginuser:'hello'})
}
}

exports.bannershowadmin=async (req,res)=>{
    const bannerrecord= await Baner.findOne()
    res.render('admin/banner.ejs',{bannerrecord})
}

exports.bannerupdateadmin=async (req,res)=>{
    //console.log(req.file)
    const id= req.params.xyz
    const{bt,bd,ld}= req.body
    if(req.file){
    await Baner.findByIdAndUpdate(id,{title:bt,desc:bd,longdesc:ld,bannerImg:req.file.filename})
     }
    else{await Baner.findByIdAndUpdate(id,{title:bt,desc:bd,longdesc:ld})}
    
    res.redirect('/admin/banner')
     
}

exports.bannerupdateformadmin=async(req,res)=>{
    const id= req.params.abc
    const bannerrecord= await Baner.findById(id)
    res.render('admin/bannerform.ejs',{bannerrecord})
}