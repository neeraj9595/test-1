const Reg= require('../models/reg')








exports.usercontrolleradmin=async(req,res)=>{
    const regrecords= await Reg.find()
    const usercount= await Reg.count()
    const useractive= await Reg.count({status:'active'})
    const userpvt= await Reg.count({role:'pvt'})
    const userpublic= await Reg.count({role:'public'})
    res.render('admin/users.ejs',{regrecords,usercount,useractive,userpvt,userpublic})
}

exports.userupdatecontrolleradmin=async(req,res)=>{
    const id= req.params.abc
    const userRecord= await Reg.findById(id)
    console.log(userRecord)
    let newStatus=null;
    if(userRecord.status=='suspended'){
        newStatus='active'
    }else{
        newStatus='suspended'
    }
    await Reg.findByIdAndUpdate(id,{status:newStatus})
    res.redirect('/admin/user')
}

exports.userrolecontrolleradmin=async (req,res)=>{
    const id=req.params.abc
    const regrecord= await Reg.findById(id)
    newRole='pvt'
    if(regrecord.role=='public'){
        newRole='pvt'
    }else{
        newRole='public'
    }
   await Reg.findByIdAndUpdate(id,{role:newRole})
   res.redirect('/admin/user')
}

exports.userdeletecontrolleradmin=async(req,res)=>{
    const id= req.params.abc
    await Reg.findByIdAndDelete(id)
    res.redirect('/admin/user')

}