const Testi= require('../models/testi')







exports.testicontrolleradmin=async(req,res)=>{
    const testiRecords= await Testi.find().sort({postedDate:-1})
    const totaltesti= await Testi.count()
    const totalpublish= await Testi.count({status:'publish'})
    const totalunpublish= await Testi.count({status:'unpublish'})
    //console.log(totaltesti)
    //console.log(totalpublish)
    //console.log(totalunpublish)
    res.render('admin/testi.ejs',{testiRecords,totaltesti,totalpublish,totalunpublish})
}

exports.testiupdatecontrolleradmin=async(req,res)=>{
    const id= req.params.xyz
    const testiRecord= await Testi.findById(id)
    let newStatus=null
    if(testiRecord.status=='unpublish'){
        newStatus='publish'
    }else{
        newStatus='unpublish'
    }
    
    await Testi.findByIdAndUpdate(id,{status:newStatus})
    res.redirect('/admin/testi')
}

exports.testideletecontrolleradmin=async(req,res)=>{
    const id= req.params.abc
    await Testi.findByIdAndDelete(id)
    res.redirect('/admin/testi')
}