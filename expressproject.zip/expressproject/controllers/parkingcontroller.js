const Parking= require('../models/parking')







exports.parkingcontrolleradmin=async(req,res)=>{
    const parkingREcord= await Parking.find()
    const parkingstatus= await Parking.count({status:'IN'})
    //console.log(parkingstatus)
    let totalparking=100
    let availableparking= (100-parkingstatus)
    res.render('admin/parking.ejs',{parkingREcord,parkingstatus,availableparking})
}

exports.parkingaddcontrolleradmin=(req,res)=>{
    res.render('admin/parkingform.ejs')
}

exports.parkinginsertcontrolleradmin=async (req,res)=>{
    let nowdate= new Date()
    const{vno,vtype,tt}=req.body
    const parkingRecord= new Parking({vnumber:vno,vtype:vtype,vintime:nowdate,status:'IN',totaltime:tt})
    await parkingRecord.save()
    //console.log(parkingRecord)
    res.redirect('/admin/parking')
}

exports.parkingoutcontrolleradmin=(req,res)=>{
    const id= req.params.id
    res.render('admin/parkingupdateform.ejs',{id})
}

exports.parkingupdatecontrolleradmin=async(req,res)=>{
    const id= req.params.id
    //const{out}=req.body
    let nowDate=new Date()
    const parkingrecord= await Parking.findById(id)
    console.log(parkingrecord)
    let totaltime= (new Date(nowDate)-new Date (parkingrecord.vintime))/(1000*60*60)
    console.log(totaltime)
    let amount=null
    if(parkingrecord.vtype=='2w'){
        amount=Math.round(totaltime*30)
    }else if(parkingrecord.vtype=='3w'){
        amount=Math.round(totaltime*50)
    }
    else if(parkingrecord.vtype=='4w'){
        amount=Math.round(totaltime*70)
    }
    else if(parkingrecord.vtype=='lw'){
        amount=Math.round(totaltime*100)
    }
    else if(parkingrecord.vtype=='hw'){
        amount= Math.round(totaltime*150)
    }

    await Parking.findByIdAndUpdate(id,{vouttime:nowDate,amountcharged:amount,status:'OUT'})
    res.redirect('/admin/parking')
}

exports.parkingprintcontrolleradmin=async(req,res)=>{
    const id= req.params.id
    const parkingrecord= await Parking.findById(id)
    res.render('admin/parkingprint.ejs',{parkingrecord})
}