const Query=require('../models/query')







exports.querycontrolleradmin=async (req,res)=>{
    const queryRecords= await Query.find().sort({postedDate:-1})
    res.render('admin/query.ejs',{queryRecords})
}

exports.queryupdatecontrolleradmin=async(req,res)=>{
    const id= req.params.abc
    const queryRecord= await Query.findById(id)
    console.log(queryRecord)
    let newStatus= null
    if(queryRecord.status=='unread'){
        newStatus='read'
    }else{
        newStatus='unread'
    }

    await Query.findByIdAndUpdate(id,{status:newStatus})
    res.redirect('/admin/query')
}

exports.querydeletecontrolleradmin=async(req,res)=>{
    const id= req.params.xyz
    await Query.findByIdAndDelete(id)
    res.redirect('/admin/query')
}