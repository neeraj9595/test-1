const mongoose= require('mongoose')





const serviceSchema= mongoose.Schema({
    img:String,
    serviceName:String,
    serviceDesc:String,
    serviceLongDesc:String,
    status:String
})





module.exports= mongoose.model('services',serviceSchema)