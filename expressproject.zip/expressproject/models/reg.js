const mongoose= require('mongoose')




const regSchema=mongoose.Schema({
    username:String,
    password:String,
    status:String,
    role:String,
    firstName:String,
    LastName:String,
    email:String,
    img:String
})






module.exports= mongoose.model('reg',regSchema)