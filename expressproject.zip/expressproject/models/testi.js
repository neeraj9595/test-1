const mongoose= require('mongoose')





const testiSchema= mongoose.Schema({
    quote:String,
    cname:String,
    status:String,
    postedDate:Date,
    userImage:String
})







module.exports= mongoose.model('testi',testiSchema)