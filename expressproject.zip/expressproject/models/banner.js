const mongoose= require('mongoose')//mudule





const bannerSchema= mongoose.Schema({
    title:String,
    desc:String,
    longdesc:String,
    bannerImg:String
})







module.exports= mongoose.model('banner',bannerSchema)