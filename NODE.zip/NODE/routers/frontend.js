const router= require('express').Router()//module
const { render } = require('ejs')
const { findByIdAndDelete } = require('../model/employee')
const Employee= require('../model/employee')
const Reg= require('../model/registration')


function handlelogin (req,res,next){
    if(req.session.isAuth){
        next()
    }else{
        res.redirect('/login')
    }
}

router.get('/insertform',(req,res)=>{
    res.render('insertform.ejs')
})



router.post('/insertdata',(req,res)=>{
    const name=req.body.name
    const address= req.body.add
    const records= new Employee({name:name,address:address})
    records.save()
    
})



router.get('/fetch',handlelogin,async(req,res)=>{
const record= await Employee.findOne()
console.log(record)
    res.render('fetch.ejs',{record})
})



router.get('/fetches',handlelogin,async(req,res)=>{
    const records= await Employee.find()
    //console.log(records)
    res.render('fetches.ejs',{records})
})




router.get('/delete/:abc',async(req,res)=>{
req.params.abc
await Employee.findByIdAndDelete(req.params.abc)
res.redirect('/fetches')
})



router.get('/update/:xyz',async(req,res)=>{
console.log(req.params.xyz)
const emprecord= await Employee.findById(req.params.xyz)
res.render('update.ejs',{emprecord})
})



router.post('/updaterecord/:abc',async(req,res)=>{
    console.log(req.params.abc)
    const{name,address}= req.body
    await Employee.findByIdAndUpdate(req.params.abc,{name:name,address:address})
    res.redirect('/fetches')
})




router.get('/registration',(req,res)=>{
    res.render('regform')
})


router.post('/regdata',async(req,res)=>{
const {username,pass}= req.body
const regrecord= new Reg({username:username,password:pass})
await regrecord.save()
//console.log(regrecord)
})




router.get('/login',(req,res)=>{
    res.render('login.ejs')
})



router.post('/loginrecord',async (req,res)=>{
    const{username,pass}= req.body
    const regrecord= await Reg.findOne({username:username})
    if(regrecord!==null){
        if(regrecord.password==pass){
            req.session.isAuth=true
            res.redirect('/fetches')
        }else{
            res.redirect('/login')
        }
    
}else
res.redirect('/login')
console.log(regrecord)
    
})




router.get('/logout',(req,res)=>{
    req.session.destroy()
    res.redirect('/login')
})





module.exports=router;
