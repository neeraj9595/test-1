let a=5

++a
console.log(a)



