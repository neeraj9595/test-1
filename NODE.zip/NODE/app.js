// inbuilt module http of node
//module format
//use-> method format
const  http= require('http');
const fs= require('fs')//module

const homePage =fs.readFileSync('./home.html');
const stylepage =fs.readFileSync('./style.css')
const image  =fs.readFileSync('./Desert.jpg')
    //console.log(homePage);


    const server =http.createServer((req,res)=>{
        if(req.url==='/'){
           //res.write(homePage)
            res.end('welcome to home' )

        }
        else if(req.url=='/style.css'){
            res.write(stylepage)
            res.end()
        }
        else if(req.url=='/Desert.jpg'){
            res.write(image)
            res.end()

        }
        else if(req.url=='/about'){
            res.end('about')
        }else{
            res.end('page not found')
        }
    })
    server.listen('5000')







