const express= require('express')//module/funtion

const app= express()//module
app.use(express.urlencoded({extended:false}))
const FrontendRouter= require('./routers/frontend')
const mongoose= require('mongoose')//module
const session= require('express-session')





mongoose.connect('mongodb://127.0.0.1:27017/NODE',()=>{
    console.log('connected to dbnode')
})


app.use(session({
    secret:'neeraj',
    saveUninitialized:false,
    resave:false
}))




app.use(FrontendRouter)
app.use(express.static('public'))
app.set('view engine','ejs')




app.listen(5000,()=>{
    console.log('server is running on port 5000')
})
